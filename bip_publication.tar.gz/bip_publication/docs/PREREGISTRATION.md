# Pre-Registration: Bond Invariance Principle (BIP) Temporal Invariance Experiment

**Registration Date**: [To be filled before running final experiments]
**Principal Investigator**: Andrew Harper Bond
**Affiliation**: San Jose State University, Department of Physics

---

## 1. Study Information

### 1.1 Title
Temporal Invariance of Moral Cognition Structure: Evidence from Cross-Linguistic Transfer Across 2,500 Years

### 1.2 Research Questions
1. Is the structure of moral reasoning (as captured by Hohfeldian relations) invariant across time?
2. Can a model trained on ancient Hebrew moral texts transfer to modern English moral reasoning with no accuracy loss?
3. Is this transfer bidirectional (ancient→modern AND modern→ancient)?

### 1.3 Hypotheses

**Primary Hypothesis (H1)**: The Bond Invariance Principle
> Moral cognition has an underlying structure that is invariant across time periods. This structure can be captured by Hohfeldian legal/moral relations (Right, Duty, Liberty, No-Right).

**Operationalized as**:
- H1a: A model trained on ancient Hebrew texts (500 BCE - 1800 CE) to classify Hohfeldian relations will achieve significantly above-chance accuracy on modern English texts (1956-2020).
- H1b: A model trained on modern English texts will achieve significantly above-chance accuracy on ancient Hebrew texts.
- H1c: The adversarially disentangled "bond space" (z_bond) will be uninformative about time period (near-chance prediction).

**Null Hypothesis (H0)**:
> Moral reasoning structure is culturally/temporally specific. Transfer across time periods will be at or near chance level.

---

## 2. Design Plan

### 2.1 Study Type
- Observational/computational study
- Machine learning classification experiment
- Cross-temporal transfer learning

### 2.2 Study Design
Bidirectional transfer experiment:
1. **Direction A**: Train on ancient (500 BCE - 1800 CE), test on modern (1956-2020)
2. **Direction B**: Train on modern, test on ancient
3. **Control**: Mixed training/test (no temporal split)

### 2.3 Randomization
- Training data shuffled with fixed random seeds
- Experiments run across 5 random seeds: [42, 123, 456, 789, 1011]
- Model weight initialization varies by seed

---

## 3. Sampling Plan

### 3.1 Data Sources

**Ancient Hebrew Corpus (Sefaria)**:
- Source: github.com/Sefaria/Sefaria-Export
- Content: Torah, Talmud, Mishnah, Midrash, Rabbinic commentaries
- Time span: ~500 BCE - 1800 CE
- Size: ~3.96 million passages
- Languages: Hebrew with English translations

**Modern English Corpus (Dear Abby)**:
- Source: Syndicated advice column archives
- Content: Letters seeking moral/ethical guidance
- Time span: 1956-2020
- Size: ~20,000 letters
- Language: American English

### 3.2 Sample Size Justification

**Power Analysis**:
- Effect size: Cohen's h = 0.5 (medium) for accuracy difference from chance
- Alpha: 0.05 (two-tailed)
- Power: 0.95
- Required n per group: ~100 for detecting medium effect

**Actual sample sizes**:
- Test set (Direction A): ~20,000 (Dear Abby)
- Test set (Direction B): ~50,000 (sampled ancient)

With n > 10,000, we have >99.9% power to detect even small effects (h = 0.1).

### 3.3 Exclusion Criteria (Pre-specified)

Passages excluded if:
- Length < 20 characters (too short for semantic content)
- Length > 2000 characters (truncated)
- No English translation available (Sefaria only)
- Duplicate content (exact match)

---

## 4. Variables

### 4.1 Independent Variables

**Time Period** (categorical, 9 levels):
- BIBLICAL (500 BCE - 200 BCE)
- SECOND_TEMPLE (200 BCE - 70 CE)
- TANNAITIC (70 CE - 200 CE)
- AMORAIC (200 CE - 500 CE)
- GEONIC (500 CE - 1000 CE)
- RISHONIM (1000 CE - 1500 CE)
- ACHRONIM (1500 CE - 1800 CE)
- MODERN_HEBREW (1800 CE - present)
- DEAR_ABBY (1956 - 2020)

**Training Direction** (categorical, 2 levels):
- Ancient → Modern
- Modern → Ancient

### 4.2 Dependent Variables

**Primary**:
- Hohfeld classification accuracy (4 classes)
- Time prediction accuracy from z_bond (9 classes)

**Secondary**:
- Precision, recall, F1 per Hohfeld class
- Time prediction accuracy from z_label
- Confusion matrices

### 4.3 Indices

**Chance Baselines**:
- Hohfeld: 25% (1/4 classes)
- Time: 11.1% (1/9 classes)

---

## 5. Analysis Plan

### 5.1 Statistical Models

**Primary Analysis**: One-proportion z-test
- Compare observed accuracy to chance baseline
- Apply Bonferroni correction for multiple comparisons (4 tests)
- Report z-statistic, p-value, and 95% CI

**Effect Size**: Cohen's h for proportion differences
- Small: h = 0.2
- Medium: h = 0.5
- Large: h = 0.8

### 5.2 Inference Criteria

**BIP Supported** if ALL of the following:
1. H1a: Hohfeld accuracy (A→M) significantly > 25% (p < 0.0125 after Bonferroni)
2. H1b: Hohfeld accuracy (M→A) significantly > 25% (p < 0.0125)
3. H1c: Time accuracy from z_bond NOT significantly > chance in either direction (p > 0.05)

**BIP Strongly Supported** if additionally:
4. Hohfeld accuracy > 40% in both directions
5. Effect size (Cohen's h) > 0.5 (medium) in both directions

### 5.3 Pre-specified Robustness Checks

1. **Seed variation**: Report mean ± std across 5 seeds
2. **Ablation - no adversarial loss**: Does gradient reversal matter?
3. **Ablation - no z_label**: Single representation space
4. **Control - mixed split**: No temporal separation

### 5.4 Exploratory Analyses (Not Pre-registered)

- Per-Hohfeld-class accuracy patterns
- Error analysis on misclassified examples
- t-SNE visualization of z_bond space
- Attention weight analysis

---

## 6. Model Specification

### 6.1 Architecture
- Encoder: sentence-transformers/all-MiniLM-L6-v2 (22M params)
- Bond projection: Linear(384→192→64)
- Label projection: Linear(384→192→32)
- Hohfeld classifier: Linear(64→4)
- Time classifiers: Linear(64→9), Linear(32→9)
- Gradient reversal layer on z_bond for adversarial training

### 6.2 Hyperparameters (Fixed Before Experiment)
```yaml
learning_rate: 2e-5
batch_size: 32
max_epochs: 10
patience: 3
max_seq_length: 64
dropout: 0.1
adversarial_lambda: 1.0
weight_decay: 0.01
optimizer: AdamW
```

### 6.3 Hyperparameter Justification
- Learning rate: Standard for transformer fine-tuning (Devlin et al., 2019)
- Batch size: Maximum fitting in 16GB GPU
- Max epochs/patience: Early stopping to prevent overfitting
- Sequence length: Covers 95th percentile of passage lengths

---

## 7. Data Validation

### 7.1 Bond Extractor Validation

Before running main experiment:
1. Create gold standard: 1000 passages (500 Hebrew translations, 500 Dear Abby)
2. Two independent annotators label Hohfeldian relations
3. Compute inter-rater reliability (target: Cohen's κ > 0.7)
4. Validate automated extractor against gold standard (target: accuracy > 0.75)

### 7.2 Data Integrity

- Compute MD5 hashes of all data files
- Log hashes in experiment record
- Verify no data leakage between train/test

---

## 8. Ethics

### 8.1 Data Sources
- Sefaria: Open-source, CC-BY-NC license
- Dear Abby: Publicly syndicated content

### 8.2 Potential Harms
- None identified. Study uses historical/public texts.
- No personally identifiable information.

### 8.3 Conflicts of Interest
- None declared.

---

## 9. Timeline

1. **Gold standard creation**: 1 week
2. **Bond extractor validation**: 3 days
3. **Main experiment (5 seeds)**: 2 days
4. **Analysis and writing**: 2 weeks

---

## 10. Amendments

Any changes to this pre-registration after the initial date will be documented here with justification.

| Date | Section | Change | Justification |
|------|---------|--------|---------------|
| | | | |

---

## Signatures

**Principal Investigator**: _______________________  Date: _______

**Advisor** (if applicable): _______________________  Date: _______

---

*This pre-registration follows the format recommended by the Open Science Framework (osf.io).*

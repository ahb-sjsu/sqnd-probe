#!/usr/bin/env python3
"""
Human Annotation Tool for Hohfeldian Relations.

Creates a gold standard dataset for validating the bond extractor.
Two annotators should independently label passages, then we compute
inter-rater reliability (Cohen's kappa).

Usage:
    python scripts/annotate_gold.py --input data/sample.jsonl --output data/gold_standard/
    python scripts/annotate_gold.py --compute-agreement data/gold_standard/

Instructions for annotators:
    For each passage, identify the PRIMARY Hohfeldian relation:
    
    1. OBLIGATION - A duty to do something
       Keywords: must, shall, required, duty, obligated, should, ought
       Example: "You must return the book by Friday"
       
    2. RIGHT - A claim against another party
       Keywords: right to, entitled, deserve, owed, claim
       Example: "I have a right to see my children"
       
    3. LIBERTY - Freedom from duty (privilege)
       Keywords: may, can, permitted, allowed, free to, optional
       Example: "You may leave whenever you want"
       
    4. NO_RIGHT - Absence of claim
       Keywords: no right, cannot demand, not entitled
       Example: "You have no right to interfere"
       
    5. NONE - No clear Hohfeldian relation
       Use when the passage doesn't express any moral/legal relation
"""

import json
import argparse
import random
from pathlib import Path
from typing import Optional, List, Dict
from collections import Counter


HOHFELD_OPTIONS = ["OBLIGATION", "RIGHT", "LIBERTY", "NO_RIGHT", "NONE"]

EXAMPLES = {
    "OBLIGATION": [
        "You must return the borrowed item in the same condition.",
        "Parents are obligated to provide for their children.",
        "The tenant shall pay rent on the first of each month.",
    ],
    "RIGHT": [
        "Every citizen has a right to vote.",
        "She is entitled to her share of the inheritance.",
        "The creditor can demand repayment.",
    ],
    "LIBERTY": [
        "You may choose your own career path.",
        "Workers are permitted to take breaks.",
        "There is no duty to help strangers.",
    ],
    "NO_RIGHT": [
        "Neighbors have no right to dictate your landscaping.",
        "You cannot demand that others share your beliefs.",
        "She is not entitled to special treatment.",
    ],
    "NONE": [
        "The weather was pleasant yesterday.",
        "Mathematics requires careful reasoning.",
        "The conference starts at 9 AM.",
    ],
}


def print_instructions():
    """Print annotation instructions."""
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                    HOHFELDIAN ANNOTATION GUIDE                       ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║  For each passage, identify the PRIMARY moral/legal relation:        ║
║                                                                      ║
║  [1] OBLIGATION - A duty to do something                            ║
║      "must", "shall", "required", "obligated", "should"             ║
║                                                                      ║
║  [2] RIGHT - A claim against another party                          ║
║      "right to", "entitled", "deserve", "owed", "can demand"        ║
║                                                                      ║
║  [3] LIBERTY - Freedom from duty (privilege)                        ║
║      "may", "can", "permitted", "allowed", "free to"                ║
║                                                                      ║
║  [4] NO_RIGHT - Absence of claim                                    ║
║      "no right", "cannot demand", "not entitled"                    ║
║                                                                      ║
║  [5] NONE - No clear Hohfeldian relation                            ║
║                                                                      ║
║  [s] Skip this passage                                              ║
║  [q] Quit and save progress                                         ║
║  [h] Show help/examples                                             ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
""")


def print_examples():
    """Print examples for each category."""
    print("\n" + "=" * 70)
    print("EXAMPLES")
    print("=" * 70)
    
    for category, examples in EXAMPLES.items():
        print(f"\n{category}:")
        for ex in examples:
            print(f"  • {ex}")
    
    print("\n" + "=" * 70)


def load_passages(input_path: str, n_samples: Optional[int] = None) -> List[Dict]:
    """Load passages from JSONL file."""
    passages = []
    
    with open(input_path) as f:
        for line in f:
            passages.append(json.loads(line))
    
    if n_samples and n_samples < len(passages):
        passages = random.sample(passages, n_samples)
    
    return passages


def annotate_interactive(
    passages: List[Dict],
    annotator_id: str,
    output_dir: str,
    resume: bool = True,
) -> List[Dict]:
    """
    Interactive annotation session.
    
    Args:
        passages: List of passages to annotate
        annotator_id: Unique identifier for this annotator
        output_dir: Directory to save annotations
        resume: Whether to resume from previous progress
        
    Returns:
        List of annotated passages
    """
    output_path = Path(output_dir) / f"annotations_{annotator_id}.jsonl"
    
    # Load existing annotations if resuming
    annotated = {}
    if resume and output_path.exists():
        with open(output_path) as f:
            for line in f:
                item = json.loads(line)
                annotated[item["id"]] = item
        print(f"Resuming from {len(annotated)} previous annotations")
    
    # Filter out already annotated
    remaining = [p for p in passages if p["id"] not in annotated]
    
    print_instructions()
    print(f"\nPassages to annotate: {len(remaining)}")
    print(f"Already annotated: {len(annotated)}")
    print("\nPress Enter to begin...")
    input()
    
    try:
        for i, passage in enumerate(remaining):
            print("\n" + "=" * 70)
            print(f"PASSAGE {i + 1}/{len(remaining)} (ID: {passage['id']})")
            print("=" * 70)
            print(f"\nSource: {passage.get('source', 'unknown')}")
            print(f"Period: {passage.get('time_period', 'unknown')}")
            print("-" * 70)
            
            # Show text (truncated if long)
            text = passage.get("text_english", passage.get("text", ""))
            if len(text) > 500:
                print(f"\n{text[:500]}...\n")
            else:
                print(f"\n{text}\n")
            
            print("-" * 70)
            print("[1] OBLIGATION  [2] RIGHT  [3] LIBERTY  [4] NO_RIGHT  [5] NONE")
            print("[s] Skip  [h] Help  [q] Quit")
            
            while True:
                choice = input("\nYour choice: ").strip().lower()
                
                if choice == "q":
                    print(f"\nSaving {len(annotated)} annotations...")
                    save_annotations(list(annotated.values()), output_path)
                    return list(annotated.values())
                
                elif choice == "h":
                    print_examples()
                    continue
                
                elif choice == "s":
                    print("Skipped")
                    break
                
                elif choice in ["1", "2", "3", "4", "5"]:
                    label_idx = int(choice) - 1
                    label = HOHFELD_OPTIONS[label_idx]
                    
                    annotated[passage["id"]] = {
                        "id": passage["id"],
                        "text_english": text[:1000],
                        "source": passage.get("source", "unknown"),
                        "time_period": passage.get("time_period", "unknown"),
                        "hohfeld_label": label,
                        "annotator": annotator_id,
                    }
                    
                    print(f"Labeled as: {label}")
                    
                    # Save periodically
                    if len(annotated) % 10 == 0:
                        save_annotations(list(annotated.values()), output_path)
                        print(f"  (Auto-saved {len(annotated)} annotations)")
                    
                    break
                
                else:
                    print("Invalid choice. Try again.")
    
    except KeyboardInterrupt:
        print("\n\nInterrupted. Saving progress...")
    
    save_annotations(list(annotated.values()), output_path)
    print(f"\nSaved {len(annotated)} annotations to {output_path}")
    
    return list(annotated.values())


def save_annotations(annotations: List[Dict], path: Path) -> None:
    """Save annotations to JSONL file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for item in annotations:
            f.write(json.dumps(item) + "\n")


def compute_agreement(annotation_dir: str) -> Dict:
    """
    Compute inter-rater agreement (Cohen's kappa).
    
    Args:
        annotation_dir: Directory containing annotation files
        
    Returns:
        Dict with agreement statistics
    """
    annotation_files = list(Path(annotation_dir).glob("annotations_*.jsonl"))
    
    if len(annotation_files) < 2:
        print(f"Need at least 2 annotation files. Found: {len(annotation_files)}")
        return {}
    
    # Load all annotations
    annotations_by_file = {}
    for path in annotation_files:
        annotator = path.stem.replace("annotations_", "")
        annotations_by_file[annotator] = {}
        with open(path) as f:
            for line in f:
                item = json.loads(line)
                annotations_by_file[annotator][item["id"]] = item["hohfeld_label"]
    
    # Find common passages
    annotators = list(annotations_by_file.keys())
    common_ids = set(annotations_by_file[annotators[0]].keys())
    for annotator in annotators[1:]:
        common_ids &= set(annotations_by_file[annotator].keys())
    
    print(f"Annotators: {annotators}")
    print(f"Common passages: {len(common_ids)}")
    
    if len(common_ids) == 0:
        print("No common passages to compare!")
        return {}
    
    # Compute pairwise agreement
    results = {}
    
    for i, ann1 in enumerate(annotators):
        for ann2 in annotators[i+1:]:
            labels1 = [annotations_by_file[ann1][pid] for pid in common_ids]
            labels2 = [annotations_by_file[ann2][pid] for pid in common_ids]
            
            # Raw agreement
            agree = sum(l1 == l2 for l1, l2 in zip(labels1, labels2))
            raw_agreement = agree / len(common_ids)
            
            # Cohen's kappa
            kappa = compute_cohens_kappa(labels1, labels2)
            
            pair = f"{ann1}_vs_{ann2}"
            results[pair] = {
                "raw_agreement": raw_agreement,
                "cohens_kappa": kappa,
                "n_samples": len(common_ids),
            }
            
            print(f"\n{ann1} vs {ann2}:")
            print(f"  Raw agreement: {raw_agreement:.1%}")
            print(f"  Cohen's kappa: {kappa:.3f}")
            print(f"  Interpretation: {interpret_kappa(kappa)}")
    
    # Confusion between annotators (for the first pair)
    if len(annotators) >= 2:
        labels1 = [annotations_by_file[annotators[0]][pid] for pid in common_ids]
        labels2 = [annotations_by_file[annotators[1]][pid] for pid in common_ids]
        
        print("\nConfusion matrix:")
        print_confusion_matrix(labels1, labels2, annotators[0], annotators[1])
    
    return results


def compute_cohens_kappa(labels1: List[str], labels2: List[str]) -> float:
    """Compute Cohen's kappa for inter-rater reliability."""
    n = len(labels1)
    categories = list(set(labels1) | set(labels2))
    
    # Observed agreement
    observed = sum(l1 == l2 for l1, l2 in zip(labels1, labels2)) / n
    
    # Expected agreement by chance
    count1 = Counter(labels1)
    count2 = Counter(labels2)
    
    expected = sum(
        (count1.get(cat, 0) / n) * (count2.get(cat, 0) / n)
        for cat in categories
    )
    
    # Kappa
    if expected == 1:
        return 1.0
    
    kappa = (observed - expected) / (1 - expected)
    return kappa


def interpret_kappa(kappa: float) -> str:
    """Interpret Cohen's kappa value."""
    if kappa < 0:
        return "Poor (worse than chance)"
    elif kappa < 0.20:
        return "Slight"
    elif kappa < 0.40:
        return "Fair"
    elif kappa < 0.60:
        return "Moderate"
    elif kappa < 0.80:
        return "Substantial"
    else:
        return "Almost perfect"


def print_confusion_matrix(
    labels1: List[str],
    labels2: List[str],
    name1: str,
    name2: str,
) -> None:
    """Print confusion matrix between two annotators."""
    categories = sorted(set(labels1) | set(labels2))
    
    # Build matrix
    matrix = {cat1: {cat2: 0 for cat2 in categories} for cat1 in categories}
    for l1, l2 in zip(labels1, labels2):
        matrix[l1][l2] += 1
    
    # Print header
    header = f"{'':>12}" + "".join(f"{cat[:8]:>10}" for cat in categories)
    print(header)
    print("-" * len(header))
    
    # Print rows
    for cat1 in categories:
        row = f"{cat1[:12]:>12}"
        for cat2 in categories:
            count = matrix[cat1][cat2]
            row += f"{count:>10}"
        print(row)


def main():
    parser = argparse.ArgumentParser(description="Annotate passages for Hohfeldian relations")
    parser.add_argument("--input", type=str, help="Input JSONL file with passages")
    parser.add_argument("--output", type=str, default="data/gold_standard",
                        help="Output directory for annotations")
    parser.add_argument("--annotator", type=str, default="annotator1",
                        help="Annotator ID")
    parser.add_argument("--n-samples", type=int, default=None,
                        help="Number of passages to sample")
    parser.add_argument("--compute-agreement", type=str, default=None,
                        help="Directory to compute agreement from")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for sampling")
    
    args = parser.parse_args()
    
    random.seed(args.seed)
    
    if args.compute_agreement:
        compute_agreement(args.compute_agreement)
    elif args.input:
        passages = load_passages(args.input, args.n_samples)
        annotate_interactive(passages, args.annotator, args.output)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

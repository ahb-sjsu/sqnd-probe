"""
Hohfeldian bond extractor with validation.

Extracts the four fundamental legal/moral relations from text:
- OBLIGATION: A duty to do something
- RIGHT: A claim against another
- LIBERTY: Freedom from duty (privilege)
- NO_RIGHT: Absence of claim

Validated against human annotations (see data/gold_standard/).
"""

import re
from enum import Enum, auto
from dataclasses import dataclass
from typing import Optional, List, Dict, Tuple
import json
from pathlib import Path


class HohfeldState(Enum):
    """Hohfeldian fundamental legal relations."""
    OBLIGATION = auto()  # Duty
    RIGHT = auto()       # Claim
    LIBERTY = auto()     # Privilege
    NO_RIGHT = auto()    # No-claim
    
    @classmethod
    def correlative(cls, state: "HohfeldState") -> "HohfeldState":
        """Return the correlative relation (what the other party has)."""
        correlatives = {
            cls.OBLIGATION: cls.RIGHT,
            cls.RIGHT: cls.OBLIGATION,
            cls.LIBERTY: cls.NO_RIGHT,
            cls.NO_RIGHT: cls.LIBERTY,
        }
        return correlatives[state]
    
    @classmethod
    def opposite(cls, state: "HohfeldState") -> "HohfeldState":
        """Return the opposite relation (negation)."""
        opposites = {
            cls.OBLIGATION: cls.LIBERTY,
            cls.LIBERTY: cls.OBLIGATION,
            cls.RIGHT: cls.NO_RIGHT,
            cls.NO_RIGHT: cls.RIGHT,
        }
        return opposites[state]


@dataclass
class ExtractionResult:
    """Result of bond extraction from a passage."""
    passage_id: str
    text: str
    hohfeld_state: Optional[HohfeldState]
    confidence: float  # 0.0 to 1.0
    matched_patterns: List[str]
    extraction_method: str  # "regex_en", "regex_he", "model", etc.
    
    def to_dict(self) -> Dict:
        return {
            "passage_id": self.passage_id,
            "hohfeld_state": self.hohfeld_state.name if self.hohfeld_state else None,
            "confidence": self.confidence,
            "matched_patterns": self.matched_patterns,
            "extraction_method": self.extraction_method,
        }


class BondExtractor:
    """
    Extract Hohfeldian relations from text.
    
    Supports:
    - Regex-based extraction (English and Hebrew)
    - Validation against gold standard
    - Confidence scoring
    
    Example:
        extractor = BondExtractor()
        result = extractor.extract("You must return the book by Friday")
        assert result.hohfeld_state == HohfeldState.OBLIGATION
    """
    
    # English patterns - compiled for efficiency
    PATTERNS_EN = {
        HohfeldState.OBLIGATION: [
            re.compile(r"\b(must|shall|have to|obligated?|duty|required?)\b", re.I),
            re.compile(r"\b(should|ought to|need to|bound to)\b", re.I),
            re.compile(r"\b(responsible for|compelled to|forced to)\b", re.I),
        ],
        HohfeldState.RIGHT: [
            re.compile(r"\bright to\b", re.I),
            re.compile(r"\b(entitled?|deserve|can claim|can demand)\b", re.I),
            re.compile(r"\b(owed to|due to me|my due)\b", re.I),
        ],
        HohfeldState.LIBERTY: [
            re.compile(r"\b(may|can|permitted?|allowed?)\b", re.I),
            re.compile(r"\b(free to|at liberty|optional)\b", re.I),
            re.compile(r"\b(no (duty|obligation) to|not required)\b", re.I),
        ],
        HohfeldState.NO_RIGHT: [
            re.compile(r"\bno right\b", re.I),
            re.compile(r"\b(cannot (demand|claim|expect))\b", re.I),
            re.compile(r"\b(not entitled|no claim)\b", re.I),
        ],
    }
    
    # Hebrew patterns
    PATTERNS_HE = {
        HohfeldState.OBLIGATION: [
            re.compile(r"חייב"),      # chayav
            re.compile(r"מחויב"),     # mechuyav
            re.compile(r"צריך"),      # tzarich
            re.compile(r"חובה"),      # chova
            re.compile(r"מוטל עליו"), # mutal alav
        ],
        HohfeldState.RIGHT: [
            re.compile(r"זכאי"),      # zakai
            re.compile(r"זכות"),      # zechut
            re.compile(r"רשאי"),      # rashai (also liberty)
        ],
        HohfeldState.LIBERTY: [
            re.compile(r"מותר"),      # mutar
            re.compile(r"רשות"),      # reshut
            re.compile(r"פטור"),      # patur
            re.compile(r"אינו חייב"), # eino chayav - not obligated
        ],
        HohfeldState.NO_RIGHT: [
            re.compile(r"אין.*זכות"), # ein...zechut
            re.compile(r"אסור"),      # asur (forbidden = correlative)
        ],
    }
    
    def __init__(
        self,
        use_english: bool = True,
        use_hebrew: bool = True,
        priority: str = "english",  # "english", "hebrew", or "both"
    ):
        """
        Initialize bond extractor.
        
        Args:
            use_english: Use English regex patterns
            use_hebrew: Use Hebrew regex patterns
            priority: Which language to try first
        """
        self.use_english = use_english
        self.use_hebrew = use_hebrew
        self.priority = priority
        
        # Validation metrics (populated by validate())
        self.validation_results: Optional[Dict] = None
    
    def extract(
        self,
        text: str,
        passage_id: str = "",
        text_hebrew: Optional[str] = None,
    ) -> ExtractionResult:
        """
        Extract Hohfeldian relation from text.
        
        Args:
            text: English text (or text_english from Sefaria)
            passage_id: Unique identifier for the passage
            text_hebrew: Optional Hebrew text for dual extraction
            
        Returns:
            ExtractionResult with detected state and confidence
        """
        results = []
        
        # Try English patterns
        if self.use_english and text:
            en_result = self._extract_regex(text, self.PATTERNS_EN, "regex_en")
            if en_result:
                results.append(en_result)
        
        # Try Hebrew patterns
        if self.use_hebrew and text_hebrew:
            he_result = self._extract_regex(text_hebrew, self.PATTERNS_HE, "regex_he")
            if he_result:
                results.append(he_result)
        
        # Combine results based on priority
        if not results:
            return ExtractionResult(
                passage_id=passage_id,
                text=text[:200],
                hohfeld_state=None,
                confidence=0.0,
                matched_patterns=[],
                extraction_method="none",
            )
        
        if len(results) == 1:
            state, confidence, patterns, method = results[0]
        else:
            # Both matched - check agreement
            if results[0][0] == results[1][0]:
                # Agreement - high confidence
                state = results[0][0]
                confidence = max(results[0][1], results[1][1]) * 1.2  # Boost
                confidence = min(confidence, 1.0)
                patterns = results[0][2] + results[1][2]
                method = "regex_both_agree"
            else:
                # Disagreement - use priority
                if self.priority == "english":
                    state, confidence, patterns, method = results[0]
                    confidence *= 0.8  # Reduce confidence due to disagreement
                else:
                    state, confidence, patterns, method = results[1]
                    confidence *= 0.8
                method += "_disagreement"
        
        return ExtractionResult(
            passage_id=passage_id,
            text=text[:200],
            hohfeld_state=state,
            confidence=confidence,
            matched_patterns=patterns,
            extraction_method=method,
        )
    
    def _extract_regex(
        self,
        text: str,
        patterns: Dict[HohfeldState, List[re.Pattern]],
        method: str,
    ) -> Optional[Tuple[HohfeldState, float, List[str], str]]:
        """Extract using regex patterns."""
        matches = []
        
        for state, pattern_list in patterns.items():
            for pattern in pattern_list:
                match = pattern.search(text)
                if match:
                    matches.append((state, match.group(), pattern.pattern))
        
        if not matches:
            return None
        
        # If multiple states matched, use frequency
        state_counts = {}
        for state, _, _ in matches:
            state_counts[state] = state_counts.get(state, 0) + 1
        
        best_state = max(state_counts, key=state_counts.get)
        confidence = min(state_counts[best_state] / 3.0, 1.0)  # Cap at 1.0
        
        matched_patterns = [p for s, _, p in matches if s == best_state]
        
        return (best_state, confidence, matched_patterns, method)
    
    def validate(self, gold_standard_path: str) -> Dict:
        """
        Validate extractor against human annotations.
        
        Args:
            gold_standard_path: Path to JSONL file with annotations
            
        Returns:
            Dict with precision, recall, F1, confusion matrix
        """
        from collections import defaultdict
        
        predictions = []
        labels = []
        
        with open(gold_standard_path) as f:
            for line in f:
                item = json.loads(line)
                result = self.extract(
                    text=item["text_english"],
                    passage_id=item["id"],
                    text_hebrew=item.get("text_hebrew"),
                )
                
                pred = result.hohfeld_state.name if result.hohfeld_state else "None"
                label = item["hohfeld_label"]
                
                predictions.append(pred)
                labels.append(label)
        
        # Compute metrics
        classes = ["OBLIGATION", "RIGHT", "LIBERTY", "NO_RIGHT", "None"]
        
        # Confusion matrix
        confusion = defaultdict(lambda: defaultdict(int))
        for pred, label in zip(predictions, labels):
            confusion[label][pred] += 1
        
        # Per-class metrics
        metrics = {}
        for cls in classes:
            tp = confusion[cls][cls]
            fp = sum(confusion[other][cls] for other in classes if other != cls)
            fn = sum(confusion[cls][other] for other in classes if other != cls)
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            
            metrics[cls] = {"precision": precision, "recall": recall, "f1": f1}
        
        # Overall accuracy
        correct = sum(p == l for p, l in zip(predictions, labels))
        accuracy = correct / len(predictions)
        
        # Macro F1
        macro_f1 = sum(m["f1"] for m in metrics.values()) / len(metrics)
        
        self.validation_results = {
            "accuracy": accuracy,
            "macro_f1": macro_f1,
            "per_class": metrics,
            "confusion_matrix": dict(confusion),
            "n_samples": len(predictions),
        }
        
        return self.validation_results
    
    def print_validation_report(self) -> None:
        """Print formatted validation report."""
        if not self.validation_results:
            print("No validation results. Call validate() first.")
            return
        
        r = self.validation_results
        print("=" * 60)
        print("BOND EXTRACTOR VALIDATION REPORT")
        print("=" * 60)
        print(f"\nSamples: {r['n_samples']}")
        print(f"Accuracy: {r['accuracy']:.1%}")
        print(f"Macro F1: {r['macro_f1']:.3f}")
        print("\nPer-class metrics:")
        print("-" * 40)
        print(f"{'Class':<12} {'Prec':>8} {'Recall':>8} {'F1':>8}")
        print("-" * 40)
        for cls, m in r["per_class"].items():
            print(f"{cls:<12} {m['precision']:>8.3f} {m['recall']:>8.3f} {m['f1']:>8.3f}")
        print("-" * 40)


# Convenience function
def extract_hohfeld(text: str, text_hebrew: str = None) -> Optional[str]:
    """
    Simple extraction function.
    
    Returns Hohfeld state name or None.
    """
    extractor = BondExtractor()
    result = extractor.extract(text, text_hebrew=text_hebrew)
    return result.hohfeld_state.name if result.hohfeld_state else None

"""
Configuration system for BIP experiments.

All hyperparameters are defined here with justifications.
No magic numbers in the codebase.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import yaml
from pathlib import Path


@dataclass
class ModelConfig:
    """Model architecture hyperparameters."""
    
    # Encoder
    encoder_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    d_model: int = 384  # MiniLM hidden size (fixed by pretrained model)
    
    # Projection heads
    d_bond: int = 64    # Bond space dimensionality
    d_label: int = 32   # Label space dimensionality
    dropout: float = 0.1
    
    # Output classes
    n_hohfeld: int = 4  # OBLIGATION, RIGHT, LIBERTY, None
    n_periods: int = 9  # Time periods in combined corpus
    
    # Justifications (for documentation)
    _justifications: Dict[str, str] = field(default_factory=lambda: {
        "d_bond": "64 dims sufficient for 4-class separation; validated via ablation",
        "d_label": "32 dims for auxiliary time prediction; smaller than bond space",
        "dropout": "0.1 standard for transformer fine-tuning (Devlin et al. 2019)",
    })


@dataclass
class TrainingConfig:
    """Training hyperparameters."""
    
    # Optimization
    learning_rate: float = 2e-5      # Standard for transformer fine-tuning
    weight_decay: float = 0.01       # AdamW default
    batch_size: int = 32             # Limited by GPU memory
    max_epochs: int = 10             # With early stopping
    
    # Early stopping
    patience: int = 3                # Epochs without improvement
    min_delta: float = 0.001         # Minimum improvement threshold
    
    # Adversarial training
    adversarial_lambda: float = 1.0  # Gradient reversal strength
    
    # Sequence length
    max_seq_length: int = 64         # 95th percentile of passage lengths
    
    # Reproducibility
    seeds: List[int] = field(default_factory=lambda: [42, 123, 456, 789, 1011])
    
    _justifications: Dict[str, str] = field(default_factory=lambda: {
        "learning_rate": "2e-5 standard for BERT fine-tuning (Devlin et al. 2019)",
        "batch_size": "32 fits in 16GB GPU; larger batches tested, no improvement",
        "max_seq_length": "64 covers 95% of passages; validated on length distribution",
        "patience": "3 epochs balances early stopping vs. convergence",
        "seeds": "5 seeds for statistical reliability (Dodge et al. 2020)",
    })


@dataclass
class DataConfig:
    """Data processing configuration."""
    
    # Corpus paths
    sefaria_path: str = "data/raw/Sefaria-Export"
    dear_abby_path: str = "data/raw/dear_abby.csv"
    
    # Preprocessing
    min_passage_length: int = 20     # Characters
    max_passage_length: int = 2000   # Characters
    
    # Time period definitions
    time_periods: Dict[str, List[str]] = field(default_factory=lambda: {
        "ancient": ["BIBLICAL", "SECOND_TEMPLE", "TANNAITIC"],
        "medieval": ["AMORAIC", "GEONIC", "RISHONIM"],
        "early_modern": ["ACHRONIM"],
        "modern": ["MODERN_HEBREW", "DEAR_ABBY"],
    })
    
    # Split configuration
    train_periods_A: List[str] = field(default_factory=lambda: [
        "BIBLICAL", "SECOND_TEMPLE", "TANNAITIC", "AMORAIC", "GEONIC", "RISHONIM"
    ])
    valid_periods_A: List[str] = field(default_factory=lambda: ["ACHRONIM"])
    test_periods_A: List[str] = field(default_factory=lambda: ["MODERN_HEBREW", "DEAR_ABBY"])
    
    # Gold standard
    gold_standard_size: int = 1000   # Total annotated passages
    gold_standard_path: str = "data/gold_standard/annotations.jsonl"


@dataclass
class BondExtractorConfig:
    """Bond extraction configuration."""
    
    # Hohfeld patterns - English
    hohfeld_patterns_en: Dict[str, List[str]] = field(default_factory=lambda: {
        "OBLIGATION": [
            r"\b(must|shall|have to|obligated?|duty|required?|should|ought)\b",
            r"\b(responsible for|bound to|compelled)\b",
        ],
        "RIGHT": [
            r"\b(right to|entitled|deserve|claim|can demand)\b",
            r"\b(owed|due to)\b",
        ],
        "LIBERTY": [
            r"\b(may|can|permitted?|allowed?|free to|at liberty)\b",
            r"\b(optional|no duty|not required)\b",
        ],
        "NO_RIGHT": [
            r"\b(no right|cannot demand|not entitled)\b",
            r"\b(no claim|cannot expect)\b",
        ],
    })
    
    # Hohfeld patterns - Hebrew (for native text, not translations)
    hohfeld_patterns_he: Dict[str, List[str]] = field(default_factory=lambda: {
        "OBLIGATION": [
            r"חייב",      # chayav - obligated
            r"מחויב",     # mechuyav - obligated
            r"צריך",      # tzarich - must/need
            r"חובה",      # chova - duty
        ],
        "RIGHT": [
            r"זכאי",      # zakai - entitled
            r"זכות",      # zechut - right
            r"רשאי",      # rashai - has right
        ],
        "LIBERTY": [
            r"מותר",      # mutar - permitted
            r"רשות",      # reshut - permission
            r"פטור",      # patur - exempt
        ],
        "NO_RIGHT": [
            r"אין.*זכות", # ein...zechut - no right
            r"אסור",      # asur - forbidden (implies no liberty, correlative)
        ],
    })
    
    # Extraction settings
    use_english_translation: bool = True  # Use text_english field from Sefaria
    fallback_to_hebrew: bool = True       # Try Hebrew patterns if English fails
    confidence_threshold: float = 0.0     # For future probabilistic extractor


@dataclass 
class ExperimentConfig:
    """Complete experiment configuration."""
    
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    data: DataConfig = field(default_factory=DataConfig)
    bond_extractor: BondExtractorConfig = field(default_factory=BondExtractorConfig)
    
    # Experiment metadata
    experiment_name: str = "bip_temporal_invariance"
    output_dir: str = "results"
    log_level: str = "INFO"
    
    # Hardware
    device: str = "auto"  # auto, cuda, cpu
    mixed_precision: bool = True
    num_workers: int = 2
    
    @classmethod
    def from_yaml(cls, path: str) -> "ExperimentConfig":
        """Load configuration from YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**data)
    
    def to_yaml(self, path: str) -> None:
        """Save configuration to YAML file."""
        # Convert dataclasses to dicts
        import dataclasses
        data = dataclasses.asdict(self)
        # Remove justification fields
        def remove_justifications(d):
            if isinstance(d, dict):
                return {k: remove_justifications(v) for k, v in d.items() 
                        if not k.startswith('_')}
            return d
        data = remove_justifications(data)
        with open(path, 'w') as f:
            yaml.dump(data, f, default_flow_style=False)
    
    def validate(self) -> List[str]:
        """Validate configuration, return list of warnings."""
        warnings = []
        
        if self.training.batch_size > 64:
            warnings.append("batch_size > 64 may cause OOM on 16GB GPUs")
        
        if len(self.training.seeds) < 5:
            warnings.append("Fewer than 5 seeds; results may not be statistically robust")
        
        if self.model.d_bond < 32:
            warnings.append("d_bond < 32 may be insufficient for 4-class separation")
        
        return warnings


# Default configuration
DEFAULT_CONFIG = ExperimentConfig()


def get_config(config_path: Optional[str] = None) -> ExperimentConfig:
    """Get configuration, optionally from file."""
    if config_path:
        return ExperimentConfig.from_yaml(config_path)
    return DEFAULT_CONFIG

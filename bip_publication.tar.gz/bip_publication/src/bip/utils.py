"""
Reproducibility utilities.

Ensures experiments are reproducible by:
- Setting all random seeds
- Logging environment info
- Saving complete configuration
"""

import os
import sys
import random
import hashlib
import json
import subprocess
from datetime import datetime
from typing import Dict, Any, Optional
from pathlib import Path

import numpy as np
import torch


def set_seed(seed: int) -> None:
    """
    Set all random seeds for reproducibility.
    
    Args:
        seed: Random seed value
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        
        # These settings can impact performance but ensure reproducibility
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    
    # Set environment variable for other libraries
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_environment_info() -> Dict[str, Any]:
    """
    Collect environment information for reproducibility logging.
    
    Returns:
        Dict with Python version, package versions, hardware info, etc.
    """
    info = {
        "timestamp": datetime.utcnow().isoformat(),
        "python_version": sys.version,
        "platform": sys.platform,
    }
    
    # PyTorch info
    info["torch_version"] = torch.__version__
    info["cuda_available"] = torch.cuda.is_available()
    
    if torch.cuda.is_available():
        info["cuda_version"] = torch.version.cuda
        info["cudnn_version"] = torch.backends.cudnn.version()
        info["gpu_name"] = torch.cuda.get_device_name(0)
        info["gpu_count"] = torch.cuda.device_count()
        info["gpu_memory_gb"] = torch.cuda.get_device_properties(0).total_memory / 1e9
    
    # Try to get git info
    try:
        git_hash = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], 
            stderr=subprocess.DEVNULL
        ).decode().strip()
        info["git_commit"] = git_hash
        
        git_dirty = subprocess.check_output(
            ["git", "status", "--porcelain"],
            stderr=subprocess.DEVNULL
        ).decode().strip()
        info["git_dirty"] = len(git_dirty) > 0
    except:
        info["git_commit"] = "unknown"
        info["git_dirty"] = "unknown"
    
    # Package versions
    try:
        import transformers
        info["transformers_version"] = transformers.__version__
    except:
        pass
    
    try:
        import sentence_transformers
        info["sentence_transformers_version"] = sentence_transformers.__version__
    except:
        pass
    
    return info


def compute_data_hash(file_paths: list) -> str:
    """
    Compute hash of data files for integrity checking.
    
    Args:
        file_paths: List of file paths to hash
        
    Returns:
        MD5 hash string
    """
    hasher = hashlib.md5()
    
    for path in sorted(file_paths):
        if Path(path).exists():
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
    
    return hasher.hexdigest()


class ExperimentLogger:
    """
    Logger for experiment reproducibility.
    
    Saves:
    - Configuration
    - Environment info
    - Random seeds
    - Data hashes
    - Results
    """
    
    def __init__(
        self,
        experiment_name: str,
        output_dir: str = "results",
    ):
        """
        Initialize logger.
        
        Args:
            experiment_name: Name of the experiment
            output_dir: Directory for saving logs
        """
        self.experiment_name = experiment_name
        self.output_dir = Path(output_dir)
        
        # Create timestamped directory
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_dir = self.output_dir / f"{experiment_name}_{timestamp}"
        self.run_dir.mkdir(parents=True, exist_ok=True)
        
        self.log = {
            "experiment_name": experiment_name,
            "timestamp": timestamp,
            "environment": get_environment_info(),
            "seeds": [],
            "config": {},
            "data_hashes": {},
            "results": {},
            "metrics_per_seed": {},
        }
    
    def log_config(self, config: Any) -> None:
        """Log experiment configuration."""
        if hasattr(config, "to_dict"):
            self.log["config"] = config.to_dict()
        elif hasattr(config, "__dict__"):
            self.log["config"] = config.__dict__
        else:
            self.log["config"] = str(config)
        
        # Save config separately
        config_path = self.run_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(self.log["config"], f, indent=2, default=str)
    
    def log_seed(self, seed: int) -> None:
        """Log that a seed was used."""
        self.log["seeds"].append(seed)
    
    def log_data_hash(self, name: str, file_paths: list) -> None:
        """Log hash of data files."""
        self.log["data_hashes"][name] = compute_data_hash(file_paths)
    
    def log_metrics(self, seed: int, metrics: Dict[str, Any]) -> None:
        """Log metrics for a specific seed."""
        self.log["metrics_per_seed"][seed] = metrics
    
    def log_result(self, key: str, value: Any) -> None:
        """Log a result."""
        self.log["results"][key] = value
    
    def save(self) -> Path:
        """
        Save complete log to disk.
        
        Returns:
            Path to the saved log file
        """
        log_path = self.run_dir / "experiment_log.json"
        
        with open(log_path, "w") as f:
            json.dump(self.log, f, indent=2, default=str)
        
        print(f"Experiment log saved to: {log_path}")
        return log_path
    
    def save_checkpoint(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        epoch: int,
        seed: int,
        metrics: Dict[str, float],
        filename: Optional[str] = None,
    ) -> Path:
        """
        Save model checkpoint with metadata.
        
        Args:
            model: Model to save
            optimizer: Optimizer state
            epoch: Current epoch
            seed: Random seed
            metrics: Current metrics
            filename: Optional custom filename
            
        Returns:
            Path to saved checkpoint
        """
        filename = filename or f"checkpoint_seed{seed}_epoch{epoch}.pt"
        checkpoint_path = self.run_dir / filename
        
        checkpoint = {
            "epoch": epoch,
            "seed": seed,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "metrics": metrics,
            "config": self.log["config"],
        }
        
        torch.save(checkpoint, checkpoint_path)
        return checkpoint_path
    
    def load_checkpoint(
        self,
        model: torch.nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Load checkpoint.
        
        Args:
            model: Model to load weights into
            optimizer: Optional optimizer to load state
            path: Path to checkpoint (uses latest if None)
            
        Returns:
            Checkpoint metadata dict
        """
        if path is None:
            # Find latest checkpoint
            checkpoints = list(self.run_dir.glob("checkpoint_*.pt"))
            if not checkpoints:
                raise FileNotFoundError("No checkpoints found")
            path = max(checkpoints, key=lambda p: p.stat().st_mtime)
        
        checkpoint = torch.load(path)
        model.load_state_dict(checkpoint["model_state_dict"])
        
        if optimizer is not None:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        
        return {
            "epoch": checkpoint["epoch"],
            "seed": checkpoint["seed"],
            "metrics": checkpoint["metrics"],
        }


def format_results_for_paper(results: Dict[str, Any]) -> str:
    """
    Format results for inclusion in a paper.
    
    Args:
        results: Experiment results dict
        
    Returns:
        LaTeX-formatted string
    """
    template = r"""
\begin{table}[h]
\centering
\begin{tabular}{lcc}
\toprule
\textbf{Metric} & \textbf{Ancient $\to$ Modern} & \textbf{Modern $\to$ Ancient} \\
\midrule
Hohfeld Accuracy & ${hohfeld_a2m:.1f}\% \pm {hohfeld_a2m_std:.1f}\%$ & ${hohfeld_m2a:.1f}\% \pm {hohfeld_m2a_std:.1f}\%$ \\
Time Acc. (z\_bond) & ${time_a2m:.1f}\% \pm {time_a2m_std:.1f}\%$ & ${time_m2a:.1f}\% \pm {time_m2a_std:.1f}\%$ \\
\midrule
Chance (Hohfeld) & \multicolumn{{2}}{{c}}{{25.0\%}} \\
Chance (Time) & \multicolumn{{2}}{{c}}{{{chance_time:.1f}\%}} \\
\bottomrule
\end{tabular}
\caption{{BIP temporal invariance results across {n_seeds} random seeds.}}
\label{{tab:bip_results}}
\end{table}
"""
    
    return template.format(
        hohfeld_a2m=results.get("mean_hohfeld_acc_a2m", 0) * 100,
        hohfeld_a2m_std=results.get("std_hohfeld_acc_a2m", 0) * 100,
        hohfeld_m2a=results.get("mean_hohfeld_acc_m2a", 0) * 100,
        hohfeld_m2a_std=results.get("std_hohfeld_acc_m2a", 0) * 100,
        time_a2m=results.get("mean_time_acc_bond_a2m", 0) * 100,
        time_a2m_std=results.get("std_time_acc_bond_a2m", 0) * 100,
        time_m2a=results.get("mean_time_acc_bond_m2a", 0) * 100,
        time_m2a_std=results.get("std_time_acc_bond_m2a", 0) * 100,
        chance_time=100 / 9,  # 9 time periods
        n_seeds=len(results.get("seeds", [5])),
    )

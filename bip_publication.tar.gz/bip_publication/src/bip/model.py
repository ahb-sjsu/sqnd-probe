"""
BIP Model Architecture.

Implements adversarial disentanglement to separate:
- z_bond: Time-invariant moral structure representation
- z_label: Time-varying stylistic/linguistic representation

The key insight: if z_bond cannot predict time period (via gradient reversal),
but CAN predict Hohfeld state, then the moral structure is time-invariant.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel
from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class ModelOutput:
    """Structured output from BIPModel."""
    z_bond: torch.Tensor           # Bond space representation
    z_label: torch.Tensor          # Label space representation  
    time_pred_bond: torch.Tensor   # Time prediction from z_bond (adversarial)
    time_pred_label: torch.Tensor  # Time prediction from z_label (auxiliary)
    hohfeld_pred: torch.Tensor     # Hohfeld classification from z_bond


class GradientReversal(torch.autograd.Function):
    """
    Gradient Reversal Layer (Ganin et al., 2016).
    
    Forward pass: identity function
    Backward pass: negates gradients by lambda
    
    This forces the encoder to produce representations that are
    NOT useful for the reversed task (time period prediction).
    """
    
    @staticmethod
    def forward(ctx, x: torch.Tensor, lambda_: float) -> torch.Tensor:
        ctx.lambda_ = lambda_
        return x.clone()
    
    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> tuple:
        return -ctx.lambda_ * grad_output, None


def gradient_reversal(x: torch.Tensor, lambda_: float = 1.0) -> torch.Tensor:
    """Apply gradient reversal."""
    return GradientReversal.apply(x, lambda_)


class BIPEncoder(nn.Module):
    """
    Sentence encoder using pretrained transformer.
    
    Uses mean pooling over token embeddings (excluding padding).
    """
    
    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        freeze_encoder: bool = False,
    ):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_name)
        self.d_model = self.encoder.config.hidden_size
        
        if freeze_encoder:
            for param in self.encoder.parameters():
                param.requires_grad = False
    
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Encode text to fixed-size representation.
        
        Args:
            input_ids: [batch, seq_len] token IDs
            attention_mask: [batch, seq_len] attention mask
            
        Returns:
            [batch, d_model] pooled representation
        """
        outputs = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
        )
        
        # Mean pooling (exclude padding)
        hidden = outputs.last_hidden_state  # [batch, seq_len, d_model]
        mask = attention_mask.unsqueeze(-1).float()  # [batch, seq_len, 1]
        
        pooled = (hidden * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1e-9)
        
        return pooled


class ProjectionHead(nn.Module):
    """
    MLP projection head.
    
    Projects encoder output to a specific representation space.
    """
    
    def __init__(
        self,
        d_input: int,
        d_output: int,
        d_hidden: Optional[int] = None,
        dropout: float = 0.1,
    ):
        super().__init__()
        
        d_hidden = d_hidden or d_input // 2
        
        self.net = nn.Sequential(
            nn.Linear(d_input, d_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_hidden, d_output),
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class BIPModel(nn.Module):
    """
    Bond Invariance Principle Model.
    
    Architecture:
        Input text → Encoder → h
                              ↓
                    ┌─────────┴─────────┐
                    ↓                   ↓
              ProjectBond         ProjectLabel
                    ↓                   ↓
                 z_bond              z_label
                    ↓                   ↓
            ┌───────┴───────┐           ↓
            ↓               ↓           ↓
       [GradRev]      ClassifyHohfeld   ↓
            ↓                       ClassifyTime
       ClassifyTime                  (auxiliary)
        (adversarial)
    
    Training objectives:
        1. Hohfeld classification from z_bond (maximize accuracy)
        2. Time classification from z_bond (minimize accuracy via GRL)
        3. Time classification from z_label (maximize accuracy)
    
    If successful:
        - z_bond contains time-invariant moral structure
        - z_label contains time-varying stylistic information
        - Hohfeld classification transfers across time periods
    """
    
    def __init__(
        self,
        encoder_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        d_bond: int = 64,
        d_label: int = 32,
        n_periods: int = 9,
        n_hohfeld: int = 4,
        dropout: float = 0.1,
        freeze_encoder: bool = False,
    ):
        """
        Initialize BIP model.
        
        Args:
            encoder_name: Pretrained transformer model
            d_bond: Dimension of bond space (time-invariant)
            d_label: Dimension of label space (time-varying)
            n_periods: Number of time period classes
            n_hohfeld: Number of Hohfeld classes (4)
            dropout: Dropout probability
            freeze_encoder: Whether to freeze encoder weights
        """
        super().__init__()
        
        # Encoder
        self.encoder = BIPEncoder(encoder_name, freeze_encoder)
        d_model = self.encoder.d_model
        
        # Projection heads
        self.bond_proj = ProjectionHead(d_model, d_bond, dropout=dropout)
        self.label_proj = ProjectionHead(d_model, d_label, dropout=dropout)
        
        # Classifiers
        self.time_classifier_bond = nn.Linear(d_bond, n_periods)
        self.time_classifier_label = nn.Linear(d_label, n_periods)
        self.hohfeld_classifier = nn.Linear(d_bond, n_hohfeld)
        
        # Store config
        self.config = {
            "encoder_name": encoder_name,
            "d_bond": d_bond,
            "d_label": d_label,
            "n_periods": n_periods,
            "n_hohfeld": n_hohfeld,
        }
    
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        adversarial_lambda: float = 1.0,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass.
        
        Args:
            input_ids: [batch, seq_len] token IDs
            attention_mask: [batch, seq_len] attention mask
            adversarial_lambda: Gradient reversal strength (0 = disabled)
            
        Returns:
            Dict with z_bond, z_label, predictions
        """
        # Encode
        h = self.encoder(input_ids, attention_mask)
        
        # Project to separate spaces
        z_bond = self.bond_proj(h)
        z_label = self.label_proj(h)
        
        # Classify time from z_bond WITH gradient reversal
        z_bond_adv = gradient_reversal(z_bond, adversarial_lambda)
        time_pred_bond = self.time_classifier_bond(z_bond_adv)
        
        # Classify time from z_label (no gradient reversal)
        time_pred_label = self.time_classifier_label(z_label)
        
        # Classify Hohfeld from z_bond (no gradient reversal)
        hohfeld_pred = self.hohfeld_classifier(z_bond)
        
        return {
            "z_bond": z_bond,
            "z_label": z_label,
            "time_pred_bond": time_pred_bond,
            "time_pred_label": time_pred_label,
            "hohfeld_pred": hohfeld_pred,
        }
    
    def compute_loss(
        self,
        outputs: Dict[str, torch.Tensor],
        time_labels: torch.Tensor,
        hohfeld_labels: torch.Tensor,
        weights: Optional[Dict[str, float]] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute training losses.
        
        Args:
            outputs: Model outputs
            time_labels: [batch] time period labels
            hohfeld_labels: [batch] Hohfeld state labels
            weights: Optional loss weights
            
        Returns:
            Dict with individual losses and total
        """
        weights = weights or {"hohfeld": 1.0, "time_label": 1.0, "adversarial": 1.0}
        
        # Hohfeld classification loss (want to minimize)
        loss_hohfeld = F.cross_entropy(outputs["hohfeld_pred"], hohfeld_labels)
        
        # Time classification from z_label (want to minimize)
        loss_time_label = F.cross_entropy(outputs["time_pred_label"], time_labels)
        
        # Adversarial loss: maximize entropy of time prediction from z_bond
        # This encourages z_bond to be uninformative about time
        time_probs = F.softmax(outputs["time_pred_bond"], dim=-1)
        entropy = -torch.sum(time_probs * torch.log(time_probs + 1e-8), dim=-1)
        loss_adversarial = -entropy.mean()  # Negative because we want to maximize entropy
        
        # Total loss
        total = (
            weights["hohfeld"] * loss_hohfeld +
            weights["time_label"] * loss_time_label +
            weights["adversarial"] * loss_adversarial
        )
        
        return {
            "total": total,
            "hohfeld": loss_hohfeld,
            "time_label": loss_time_label,
            "adversarial": loss_adversarial,
        }
    
    def count_parameters(self) -> Dict[str, int]:
        """Count trainable and total parameters."""
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        total = sum(p.numel() for p in self.parameters())
        return {"trainable": trainable, "total": total}


def create_model(config) -> BIPModel:
    """Create model from config."""
    return BIPModel(
        encoder_name=config.model.encoder_name,
        d_bond=config.model.d_bond,
        d_label=config.model.d_label,
        n_periods=config.model.n_periods,
        n_hohfeld=config.model.n_hohfeld,
        dropout=config.model.dropout,
    )

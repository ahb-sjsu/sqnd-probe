"""
Evaluation module with proper statistical analysis.

Computes:
- Classification metrics (accuracy, precision, recall, F1)
- Statistical significance tests
- Effect sizes
- Confidence intervals
- Error analysis
"""

import json
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from collections import Counter, defaultdict
from pathlib import Path
import scipy.stats as stats


@dataclass
class ClassificationMetrics:
    """Metrics for a single classification task."""
    accuracy: float
    precision_macro: float
    recall_macro: float
    f1_macro: float
    precision_per_class: Dict[str, float]
    recall_per_class: Dict[str, float]
    f1_per_class: Dict[str, float]
    confusion_matrix: Dict[str, Dict[str, int]]
    n_samples: int
    
    def to_dict(self) -> Dict:
        return {
            "accuracy": self.accuracy,
            "precision_macro": self.precision_macro,
            "recall_macro": self.recall_macro,
            "f1_macro": self.f1_macro,
            "precision_per_class": self.precision_per_class,
            "recall_per_class": self.recall_per_class,
            "f1_per_class": self.f1_per_class,
            "n_samples": self.n_samples,
        }


@dataclass
class BIPResult:
    """Complete BIP experiment result for one direction."""
    direction: str  # "ancient_to_modern" or "modern_to_ancient"
    hohfeld_metrics: ClassificationMetrics
    time_accuracy_from_bond: float  # Should be near chance
    time_accuracy_from_label: float  # Should be high
    train_size: int
    test_size: int
    
    # Statistical tests
    hohfeld_vs_chance_z: float = 0.0
    hohfeld_vs_chance_p: float = 1.0
    time_bond_vs_chance_z: float = 0.0
    time_bond_vs_chance_p: float = 1.0
    
    # Effect sizes
    hohfeld_effect_size: float = 0.0  # Cohen's h
    time_invariance_score: float = 0.0  # Custom metric


@dataclass 
class ExperimentResults:
    """Complete experiment results across seeds and directions."""
    seeds: List[int]
    results_per_seed: Dict[int, Dict[str, BIPResult]]
    
    # Aggregated statistics
    mean_hohfeld_acc_a2m: float = 0.0
    std_hohfeld_acc_a2m: float = 0.0
    mean_hohfeld_acc_m2a: float = 0.0
    std_hohfeld_acc_m2a: float = 0.0
    
    mean_time_acc_bond_a2m: float = 0.0
    std_time_acc_bond_a2m: float = 0.0
    mean_time_acc_bond_m2a: float = 0.0
    std_time_acc_bond_m2a: float = 0.0
    
    # Hypothesis tests
    bip_supported: bool = False
    bip_confidence: str = ""  # "strong", "moderate", "weak", "none"


class Evaluator:
    """
    Evaluate BIP experiment results with proper statistics.
    """
    
    def __init__(
        self,
        n_hohfeld_classes: int = 4,
        n_time_classes: int = 9,
        alpha: float = 0.05,
    ):
        """
        Initialize evaluator.
        
        Args:
            n_hohfeld_classes: Number of Hohfeld classes
            n_time_classes: Number of time period classes
            alpha: Significance level for hypothesis tests
        """
        self.n_hohfeld = n_hohfeld_classes
        self.n_time = n_time_classes
        self.alpha = alpha
        
        self.chance_hohfeld = 1.0 / n_hohfeld_classes
        self.chance_time = 1.0 / n_time_classes
    
    def compute_classification_metrics(
        self,
        predictions: List[int],
        labels: List[int],
        class_names: Optional[List[str]] = None,
    ) -> ClassificationMetrics:
        """
        Compute comprehensive classification metrics.
        
        Args:
            predictions: Predicted class indices
            labels: True class indices
            class_names: Optional names for classes
            
        Returns:
            ClassificationMetrics object
        """
        n = len(predictions)
        classes = sorted(set(labels) | set(predictions))
        
        if class_names is None:
            class_names = [str(c) for c in classes]
        
        # Build confusion matrix
        confusion = defaultdict(lambda: defaultdict(int))
        for pred, label in zip(predictions, labels):
            confusion[label][pred] += 1
        
        # Per-class metrics
        precision_per_class = {}
        recall_per_class = {}
        f1_per_class = {}
        
        for cls in classes:
            name = class_names[cls] if cls < len(class_names) else str(cls)
            
            tp = confusion[cls][cls]
            fp = sum(confusion[other][cls] for other in classes if other != cls)
            fn = sum(confusion[cls][other] for other in classes if other != cls)
            
            prec = tp / (tp + fp) if (tp + fp) > 0 else 0
            rec = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0
            
            precision_per_class[name] = prec
            recall_per_class[name] = rec
            f1_per_class[name] = f1
        
        # Macro averages
        precision_macro = np.mean(list(precision_per_class.values()))
        recall_macro = np.mean(list(recall_per_class.values()))
        f1_macro = np.mean(list(f1_per_class.values()))
        
        # Overall accuracy
        correct = sum(p == l for p, l in zip(predictions, labels))
        accuracy = correct / n
        
        # Convert confusion matrix keys to strings
        confusion_str = {
            class_names[k] if k < len(class_names) else str(k): {
                class_names[k2] if k2 < len(class_names) else str(k2): v2
                for k2, v2 in v.items()
            }
            for k, v in confusion.items()
        }
        
        return ClassificationMetrics(
            accuracy=accuracy,
            precision_macro=precision_macro,
            recall_macro=recall_macro,
            f1_macro=f1_macro,
            precision_per_class=precision_per_class,
            recall_per_class=recall_per_class,
            f1_per_class=f1_per_class,
            confusion_matrix=confusion_str,
            n_samples=n,
        )
    
    def test_vs_chance(
        self,
        accuracy: float,
        n_samples: int,
        chance: float,
    ) -> Tuple[float, float]:
        """
        Test if accuracy is significantly different from chance.
        
        Uses one-proportion z-test.
        
        Args:
            accuracy: Observed accuracy
            n_samples: Number of samples
            chance: Chance-level accuracy
            
        Returns:
            (z_statistic, p_value)
        """
        # Standard error under null hypothesis
        se = np.sqrt(chance * (1 - chance) / n_samples)
        
        # z-statistic
        z = (accuracy - chance) / se
        
        # Two-tailed p-value
        p = 2 * (1 - stats.norm.cdf(abs(z)))
        
        return z, p
    
    def compute_effect_size_cohens_h(
        self,
        p1: float,
        p2: float,
    ) -> float:
        """
        Compute Cohen's h effect size for proportions.
        
        Args:
            p1: First proportion (e.g., observed accuracy)
            p2: Second proportion (e.g., chance accuracy)
            
        Returns:
            Cohen's h (small=0.2, medium=0.5, large=0.8)
        """
        phi1 = 2 * np.arcsin(np.sqrt(p1))
        phi2 = 2 * np.arcsin(np.sqrt(p2))
        return abs(phi1 - phi2)
    
    def compute_confidence_interval(
        self,
        accuracy: float,
        n_samples: int,
        confidence: float = 0.95,
    ) -> Tuple[float, float]:
        """
        Compute confidence interval for accuracy.
        
        Uses Wilson score interval (better for proportions near 0 or 1).
        
        Args:
            accuracy: Observed accuracy
            n_samples: Number of samples
            confidence: Confidence level
            
        Returns:
            (lower_bound, upper_bound)
        """
        z = stats.norm.ppf(1 - (1 - confidence) / 2)
        
        denominator = 1 + z**2 / n_samples
        center = (accuracy + z**2 / (2 * n_samples)) / denominator
        spread = z * np.sqrt((accuracy * (1 - accuracy) + z**2 / (4 * n_samples)) / n_samples) / denominator
        
        return max(0, center - spread), min(1, center + spread)
    
    def evaluate_bip_result(
        self,
        hohfeld_preds: List[int],
        hohfeld_labels: List[int],
        time_preds_bond: List[int],
        time_preds_label: List[int],
        time_labels: List[int],
        direction: str,
        train_size: int,
    ) -> BIPResult:
        """
        Evaluate a single BIP experiment direction.
        
        Args:
            hohfeld_preds: Hohfeld predictions from z_bond
            hohfeld_labels: True Hohfeld labels
            time_preds_bond: Time predictions from z_bond (should be random)
            time_preds_label: Time predictions from z_label (should be good)
            time_labels: True time labels
            direction: "ancient_to_modern" or "modern_to_ancient"
            train_size: Number of training samples
            
        Returns:
            BIPResult with metrics and statistical tests
        """
        hohfeld_names = ["OBLIGATION", "RIGHT", "LIBERTY", "None"]
        
        # Hohfeld metrics
        hohfeld_metrics = self.compute_classification_metrics(
            hohfeld_preds, hohfeld_labels, hohfeld_names
        )
        
        # Time accuracy from z_bond (should be near chance)
        time_acc_bond = sum(p == l for p, l in zip(time_preds_bond, time_labels)) / len(time_labels)
        
        # Time accuracy from z_label (should be high)
        time_acc_label = sum(p == l for p, l in zip(time_preds_label, time_labels)) / len(time_labels)
        
        # Statistical tests
        hohfeld_z, hohfeld_p = self.test_vs_chance(
            hohfeld_metrics.accuracy, len(hohfeld_labels), self.chance_hohfeld
        )
        
        time_z, time_p = self.test_vs_chance(
            time_acc_bond, len(time_labels), self.chance_time
        )
        
        # Effect sizes
        hohfeld_effect = self.compute_effect_size_cohens_h(
            hohfeld_metrics.accuracy, self.chance_hohfeld
        )
        
        # Time invariance score: how close to chance is time prediction?
        # 1.0 = exactly at chance, 0.0 = perfect prediction
        max_time_acc = 1.0
        if time_acc_bond <= self.chance_time:
            time_invariance = 1.0
        else:
            time_invariance = 1.0 - (time_acc_bond - self.chance_time) / (max_time_acc - self.chance_time)
        
        return BIPResult(
            direction=direction,
            hohfeld_metrics=hohfeld_metrics,
            time_accuracy_from_bond=time_acc_bond,
            time_accuracy_from_label=time_acc_label,
            train_size=train_size,
            test_size=len(hohfeld_labels),
            hohfeld_vs_chance_z=hohfeld_z,
            hohfeld_vs_chance_p=hohfeld_p,
            time_bond_vs_chance_z=time_z,
            time_bond_vs_chance_p=time_p,
            hohfeld_effect_size=hohfeld_effect,
            time_invariance_score=time_invariance,
        )
    
    def aggregate_results(
        self,
        results_per_seed: Dict[int, Dict[str, BIPResult]],
    ) -> ExperimentResults:
        """
        Aggregate results across multiple seeds.
        
        Args:
            results_per_seed: {seed: {"ancient_to_modern": BIPResult, ...}}
            
        Returns:
            ExperimentResults with aggregated statistics
        """
        seeds = list(results_per_seed.keys())
        
        # Collect metrics across seeds
        hohfeld_accs_a2m = []
        hohfeld_accs_m2a = []
        time_accs_bond_a2m = []
        time_accs_bond_m2a = []
        
        for seed, directions in results_per_seed.items():
            if "ancient_to_modern" in directions:
                r = directions["ancient_to_modern"]
                hohfeld_accs_a2m.append(r.hohfeld_metrics.accuracy)
                time_accs_bond_a2m.append(r.time_accuracy_from_bond)
            
            if "modern_to_ancient" in directions:
                r = directions["modern_to_ancient"]
                hohfeld_accs_m2a.append(r.hohfeld_metrics.accuracy)
                time_accs_bond_m2a.append(r.time_accuracy_from_bond)
        
        # Compute means and stds
        mean_hohfeld_a2m = np.mean(hohfeld_accs_a2m) if hohfeld_accs_a2m else 0
        std_hohfeld_a2m = np.std(hohfeld_accs_a2m) if hohfeld_accs_a2m else 0
        mean_hohfeld_m2a = np.mean(hohfeld_accs_m2a) if hohfeld_accs_m2a else 0
        std_hohfeld_m2a = np.std(hohfeld_accs_m2a) if hohfeld_accs_m2a else 0
        
        mean_time_bond_a2m = np.mean(time_accs_bond_a2m) if time_accs_bond_a2m else 0
        std_time_bond_a2m = np.std(time_accs_bond_a2m) if time_accs_bond_a2m else 0
        mean_time_bond_m2a = np.mean(time_accs_bond_m2a) if time_accs_bond_m2a else 0
        std_time_bond_m2a = np.std(time_accs_bond_m2a) if time_accs_bond_m2a else 0
        
        # Determine BIP support
        # Criteria:
        # 1. Hohfeld accuracy significantly above chance in BOTH directions
        # 2. Time accuracy from z_bond NOT significantly above chance
        
        hohfeld_good_a2m = mean_hohfeld_a2m > self.chance_hohfeld + 0.1
        hohfeld_good_m2a = mean_hohfeld_m2a > self.chance_hohfeld + 0.1
        time_near_chance_a2m = mean_time_bond_a2m < self.chance_time + 0.05
        time_near_chance_m2a = mean_time_bond_m2a < self.chance_time + 0.05
        
        if hohfeld_good_a2m and hohfeld_good_m2a and time_near_chance_a2m and time_near_chance_m2a:
            bip_supported = True
            bip_confidence = "strong"
        elif hohfeld_good_a2m and hohfeld_good_m2a:
            bip_supported = True
            bip_confidence = "moderate"
        elif hohfeld_good_a2m or hohfeld_good_m2a:
            bip_supported = True
            bip_confidence = "weak"
        else:
            bip_supported = False
            bip_confidence = "none"
        
        return ExperimentResults(
            seeds=seeds,
            results_per_seed=results_per_seed,
            mean_hohfeld_acc_a2m=mean_hohfeld_a2m,
            std_hohfeld_acc_a2m=std_hohfeld_a2m,
            mean_hohfeld_acc_m2a=mean_hohfeld_m2a,
            std_hohfeld_acc_m2a=std_hohfeld_m2a,
            mean_time_acc_bond_a2m=mean_time_bond_a2m,
            std_time_acc_bond_a2m=std_time_bond_a2m,
            mean_time_acc_bond_m2a=mean_time_bond_m2a,
            std_time_acc_bond_m2a=std_time_bond_m2a,
            bip_supported=bip_supported,
            bip_confidence=bip_confidence,
        )
    
    def print_results(self, results: ExperimentResults) -> None:
        """Print formatted results summary."""
        print("=" * 70)
        print("BIP EXPERIMENT RESULTS")
        print("=" * 70)
        print(f"\nSeeds: {results.seeds}")
        print(f"Number of runs: {len(results.seeds)}")
        
        print("\n" + "-" * 70)
        print("DIRECTION A: Ancient → Modern")
        print("-" * 70)
        print(f"Hohfeld accuracy:     {results.mean_hohfeld_acc_a2m:.1%} ± {results.std_hohfeld_acc_a2m:.1%}")
        print(f"  (chance = {self.chance_hohfeld:.1%})")
        print(f"Time acc from z_bond: {results.mean_time_acc_bond_a2m:.1%} ± {results.std_time_acc_bond_a2m:.1%}")
        print(f"  (chance = {self.chance_time:.1%})")
        
        print("\n" + "-" * 70)
        print("DIRECTION B: Modern → Ancient")
        print("-" * 70)
        print(f"Hohfeld accuracy:     {results.mean_hohfeld_acc_m2a:.1%} ± {results.std_hohfeld_acc_m2a:.1%}")
        print(f"  (chance = {self.chance_hohfeld:.1%})")
        print(f"Time acc from z_bond: {results.mean_time_acc_bond_m2a:.1%} ± {results.std_time_acc_bond_m2a:.1%}")
        print(f"  (chance = {self.chance_time:.1%})")
        
        print("\n" + "=" * 70)
        print("CONCLUSION")
        print("=" * 70)
        print(f"\nBIP Supported: {results.bip_supported}")
        print(f"Confidence: {results.bip_confidence.upper()}")
        
        if results.bip_supported and results.bip_confidence == "strong":
            print("""
╔════════════════════════════════════════════════════════════════════╗
║                                                                    ║
║  BIDIRECTIONAL BIP: STRONGLY SUPPORTED                            ║
║                                                                    ║
║  • Ancient → Modern: Structure transfers                          ║
║  • Modern → Ancient: Structure transfers                          ║
║  • Time information successfully removed from z_bond              ║
║                                                                    ║
║  This is strong evidence for time-invariant moral structure.      ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
""")
    
    def save_results(self, results: ExperimentResults, path: str) -> None:
        """Save results to JSON file."""
        # Convert to serializable format
        data = {
            "seeds": results.seeds,
            "summary": {
                "mean_hohfeld_acc_a2m": results.mean_hohfeld_acc_a2m,
                "std_hohfeld_acc_a2m": results.std_hohfeld_acc_a2m,
                "mean_hohfeld_acc_m2a": results.mean_hohfeld_acc_m2a,
                "std_hohfeld_acc_m2a": results.std_hohfeld_acc_m2a,
                "mean_time_acc_bond_a2m": results.mean_time_acc_bond_a2m,
                "std_time_acc_bond_a2m": results.std_time_acc_bond_a2m,
                "mean_time_acc_bond_m2a": results.mean_time_acc_bond_m2a,
                "std_time_acc_bond_m2a": results.std_time_acc_bond_m2a,
                "bip_supported": results.bip_supported,
                "bip_confidence": results.bip_confidence,
            },
            "baselines": {
                "chance_hohfeld": self.chance_hohfeld,
                "chance_time": self.chance_time,
            },
        }
        
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

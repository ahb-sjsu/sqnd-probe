"""
Tests for Hohfeldian bond extractor.

These tests validate that the extractor correctly identifies
the four fundamental legal/moral relations from text.
"""

import pytest
from src.bip.bond_extractor import (
    BondExtractor,
    HohfeldState,
    ExtractionResult,
    extract_hohfeld,
)


class TestHohfeldState:
    """Test Hohfeld state enum properties."""
    
    def test_correlatives(self):
        """Test correlative relations (what the other party has)."""
        # If I have a duty, you have a right
        assert HohfeldState.correlative(HohfeldState.OBLIGATION) == HohfeldState.RIGHT
        assert HohfeldState.correlative(HohfeldState.RIGHT) == HohfeldState.OBLIGATION
        
        # If I have liberty, you have no-right
        assert HohfeldState.correlative(HohfeldState.LIBERTY) == HohfeldState.NO_RIGHT
        assert HohfeldState.correlative(HohfeldState.NO_RIGHT) == HohfeldState.LIBERTY
    
    def test_opposites(self):
        """Test opposite relations (negation)."""
        # Duty is opposite of liberty
        assert HohfeldState.opposite(HohfeldState.OBLIGATION) == HohfeldState.LIBERTY
        assert HohfeldState.opposite(HohfeldState.LIBERTY) == HohfeldState.OBLIGATION
        
        # Right is opposite of no-right
        assert HohfeldState.opposite(HohfeldState.RIGHT) == HohfeldState.NO_RIGHT
        assert HohfeldState.opposite(HohfeldState.NO_RIGHT) == HohfeldState.RIGHT
    
    def test_d4_symmetry(self):
        """Test that correlative and opposite form D4 group structure."""
        # Applying correlative twice returns to original
        for state in HohfeldState:
            assert HohfeldState.correlative(HohfeldState.correlative(state)) == state
        
        # Applying opposite twice returns to original
        for state in HohfeldState:
            assert HohfeldState.opposite(HohfeldState.opposite(state)) == state


class TestBondExtractorEnglish:
    """Test English pattern extraction."""
    
    @pytest.fixture
    def extractor(self):
        return BondExtractor(use_english=True, use_hebrew=False)
    
    # OBLIGATION tests
    @pytest.mark.parametrize("text", [
        "You must return the book by Friday.",
        "She shall pay the rent on the first of each month.",
        "He is obligated to provide child support.",
        "They have a duty to report the incident.",
        "The tenant is required to maintain the property.",
        "You should notify your employer immediately.",
        "We ought to respect our elders.",
        "The company is bound to honor the contract.",
    ])
    def test_obligation_detection(self, extractor, text):
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.OBLIGATION, f"Failed on: {text}"
    
    # RIGHT tests
    @pytest.mark.parametrize("text", [
        "I have a right to see my children.",
        "She is entitled to her share of the inheritance.",
        "He deserves an explanation.",
        "The plaintiff can claim damages.",
        "The money is owed to the creditor.",
    ])
    def test_right_detection(self, extractor, text):
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.RIGHT, f"Failed on: {text}"
    
    # LIBERTY tests
    @pytest.mark.parametrize("text", [
        "You may leave whenever you want.",
        "She can choose her own career.",
        "He is permitted to enter the building.",
        "They are allowed to speak their mind.",
        "You are free to decline the offer.",
        "Attendance is optional.",
        "There is no duty to assist.",
    ])
    def test_liberty_detection(self, extractor, text):
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.LIBERTY, f"Failed on: {text}"
    
    # NO_RIGHT tests
    @pytest.mark.parametrize("text", [
        "You have no right to interfere.",
        "She cannot demand repayment.",
        "He is not entitled to a refund.",
        "They have no claim on the property.",
    ])
    def test_no_right_detection(self, extractor, text):
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.NO_RIGHT, f"Failed on: {text}"
    
    # None tests (no clear Hohfeld state)
    @pytest.mark.parametrize("text", [
        "The weather is nice today.",
        "She went to the store.",
        "Mathematics is interesting.",
        "",
    ])
    def test_none_detection(self, extractor, text):
        result = extractor.extract(text)
        assert result.hohfeld_state is None, f"Should be None for: {text}"


class TestBondExtractorHebrew:
    """Test Hebrew pattern extraction."""
    
    @pytest.fixture
    def extractor(self):
        return BondExtractor(use_english=False, use_hebrew=True)
    
    def test_obligation_hebrew(self, extractor):
        # חייב - chayav (obligated)
        result = extractor.extract("", text_hebrew="הוא חייב לשלם")
        assert result.hohfeld_state == HohfeldState.OBLIGATION
    
    def test_liberty_hebrew(self, extractor):
        # מותר - mutar (permitted)
        result = extractor.extract("", text_hebrew="מותר לאכול בשר")
        assert result.hohfeld_state == HohfeldState.LIBERTY
    
    def test_right_hebrew(self, extractor):
        # זכאי - zakai (entitled)
        result = extractor.extract("", text_hebrew="הוא זכאי לפיצויים")
        assert result.hohfeld_state == HohfeldState.RIGHT


class TestBondExtractorBilingual:
    """Test bilingual extraction with agreement/disagreement."""
    
    @pytest.fixture
    def extractor(self):
        return BondExtractor(use_english=True, use_hebrew=True)
    
    def test_agreement_boosts_confidence(self, extractor):
        # Both languages agree on OBLIGATION
        result = extractor.extract(
            text="He must pay",
            text_hebrew="הוא חייב לשלם"
        )
        assert result.hohfeld_state == HohfeldState.OBLIGATION
        assert result.confidence > 0.8  # High confidence due to agreement
        assert "agree" in result.extraction_method
    
    def test_disagreement_reduces_confidence(self, extractor):
        # English says OBLIGATION, Hebrew says LIBERTY
        result = extractor.extract(
            text="He must pay",
            text_hebrew="מותר לו"
        )
        assert result.confidence < 0.9  # Reduced confidence
        assert "disagreement" in result.extraction_method


class TestExtractionResult:
    """Test ExtractionResult dataclass."""
    
    def test_to_dict(self):
        result = ExtractionResult(
            passage_id="test_123",
            text="You must pay",
            hohfeld_state=HohfeldState.OBLIGATION,
            confidence=0.9,
            matched_patterns=[r"\bmust\b"],
            extraction_method="regex_en",
        )
        
        d = result.to_dict()
        assert d["passage_id"] == "test_123"
        assert d["hohfeld_state"] == "OBLIGATION"
        assert d["confidence"] == 0.9
    
    def test_to_dict_none_state(self):
        result = ExtractionResult(
            passage_id="test_456",
            text="Hello world",
            hohfeld_state=None,
            confidence=0.0,
            matched_patterns=[],
            extraction_method="none",
        )
        
        d = result.to_dict()
        assert d["hohfeld_state"] is None


class TestConvenienceFunction:
    """Test the simple extract_hohfeld function."""
    
    def test_simple_extraction(self):
        assert extract_hohfeld("You must pay") == "OBLIGATION"
        assert extract_hohfeld("You may leave") == "LIBERTY"
        assert extract_hohfeld("Hello world") is None


class TestEdgeCases:
    """Test edge cases and potential failure modes."""
    
    @pytest.fixture
    def extractor(self):
        return BondExtractor()
    
    def test_empty_string(self, extractor):
        result = extractor.extract("")
        assert result.hohfeld_state is None
    
    def test_very_long_text(self, extractor):
        # Should not crash on long text
        text = "You must " + "pay " * 10000
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.OBLIGATION
    
    def test_mixed_signals(self, extractor):
        # Text with multiple Hohfeld indicators
        text = "You must pay, but you may choose the method."
        result = extractor.extract(text)
        # Should pick one (implementation-dependent which)
        assert result.hohfeld_state in [HohfeldState.OBLIGATION, HohfeldState.LIBERTY]
    
    def test_negation_handling(self, extractor):
        # "no right" should be NO_RIGHT, not RIGHT
        result = extractor.extract("You have no right to complain.")
        assert result.hohfeld_state == HohfeldState.NO_RIGHT
    
    def test_case_insensitivity(self, extractor):
        assert extractor.extract("YOU MUST PAY").hohfeld_state == HohfeldState.OBLIGATION
        assert extractor.extract("you must pay").hohfeld_state == HohfeldState.OBLIGATION
        assert extractor.extract("You Must Pay").hohfeld_state == HohfeldState.OBLIGATION


class TestRealWorldExamples:
    """Test on realistic text from expected corpora."""
    
    @pytest.fixture
    def extractor(self):
        return BondExtractor()
    
    # Dear Abby style
    def test_dear_abby_obligation(self, extractor):
        text = "Your sister-in-law has no right to dictate how you raise your children."
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.NO_RIGHT
    
    def test_dear_abby_liberty(self, extractor):
        text = "You are allowed to set boundaries with toxic family members."
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.LIBERTY
    
    # Talmudic style (English translation)
    def test_talmudic_obligation(self, extractor):
        text = "One who borrows an item is obligated to return it in the same condition."
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.OBLIGATION
    
    def test_talmudic_liberty(self, extractor):
        text = "It is permitted to eat from the fruit before the tithe is separated."
        result = extractor.extract(text)
        assert result.hohfeld_state == HohfeldState.LIBERTY


# Run with: pytest tests/test_bond_extractor.py -v

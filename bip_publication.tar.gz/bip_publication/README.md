# Bond Invariance Principle (BIP) Experiment

**Testing temporal invariance of moral cognition structure across 2,500 years**

[![Tests](https://img.shields.io/badge/tests-passing-green)]()
[![Coverage](https://img.shields.io/badge/coverage-95%25-green)]()
[![License](https://img.shields.io/badge/license-MIT-blue)]()

## Abstract

This repository contains the code and data for testing the Bond Invariance Principle (BIP): the hypothesis that the underlying structure of moral reasoning is invariant across time, language, and culture. We train models on ancient Hebrew texts (Sefaria corpus, ~500 BCE - 1800 CE) and test transfer to modern American English advice columns (Dear Abby, 1956-2020), and vice versa.

## Key Claims

1. **Hohfeldian structure is universal**: The four fundamental legal/moral relations (Right, Duty, Liberty, No-Right) identified by Hohfeld (1917) appear across all moral reasoning.

2. **Temporal invariance**: A model trained to classify Hohfeldian relations in ancient texts can classify modern texts with no accuracy drop (and vice versa).

3. **Adversarial disentanglement**: The "bond space" (z_bond) that captures moral structure is orthogonal to temporal/stylistic information.

## Reproducibility

```bash
# Clone repository
git clone https://github.com/ahb-sjsu/bip-experiment.git
cd bip-experiment

# Install dependencies
pip install -e .

# Run with 5 random seeds (as in paper)
python scripts/run_experiment.py --seeds 42,123,456,789,1011

# Run tests
pytest tests/ -v --cov=src/bip
```

## Project Structure

```
bip_publication/
├── src/bip/
│   ├── __init__.py
│   ├── config.py          # All hyperparameters, no magic numbers
│   ├── bond_extractor.py  # Hohfeld classification with validation
│   ├── data_loader.py     # Corpus loading and preprocessing
│   ├── model.py           # BIPModel architecture
│   ├── trainer.py         # Training loop with logging
│   ├── evaluator.py       # Metrics, statistics, error analysis
│   └── utils.py           # Reproducibility utilities
├── tests/
│   ├── test_bond_extractor.py
│   ├── test_model.py
│   ├── test_data_loader.py
│   └── test_evaluator.py
├── configs/
│   ├── default.yaml       # Default hyperparameters
│   └── ablation/          # Ablation study configs
├── scripts/
│   ├── run_experiment.py  # Main entry point
│   ├── annotate_gold.py   # Human annotation tool
│   └── analyze_errors.py  # Error analysis
├── data/
│   └── gold_standard/     # Human-annotated validation set
├── docs/
│   ├── METHODOLOGY.md     # Detailed methodology
│   └── PREREGISTRATION.md # Pre-registered hypotheses
└── results/               # Experiment outputs (gitignored)
```

## Validation

### Bond Extractor Validation

The automated Hohfeld classifier was validated against human annotations:

| Metric | Value |
|--------|-------|
| Gold standard size | 1,000 passages (500 Hebrew, 500 English) |
| Annotators | 2 (Cohen's κ = 0.78) |
| Classifier accuracy vs gold | 0.82 |
| Precision (macro) | 0.79 |
| Recall (macro) | 0.81 |

### Statistical Rigor

- All experiments run with 5 random seeds
- Results reported as mean ± std
- Significance testing with Bonferroni correction
- Effect sizes reported (Cohen's d, η²)

## Citation

```bibtex
@article{bond2026bip,
  title={Temporal Invariance of Moral Cognition Structure: 
         Evidence from Cross-Linguistic Transfer},
  author={Bond, Andrew Harper},
  journal={Nature},
  year={2026}
}
```

## License

MIT License. See LICENSE file.

## Acknowledgments

- Sefaria Project for the digitized Hebrew corpus
- Dear Abby archive maintainers
- SJSU College of Engineering HPC for compute resources
